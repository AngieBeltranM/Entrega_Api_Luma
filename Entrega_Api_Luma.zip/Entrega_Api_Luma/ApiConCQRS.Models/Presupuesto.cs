﻿using System;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Models
{
    [Table("Presupuesto")]
    public class Presupuesto
    {
        [Key]
        public int id_presupuesto { get; set; }

        public int id_usuario { get; set; }
        public decimal monto_limite { get; set; }
        public string periodo { get; set; } = string.Empty;
        public DateTime fecha_inicio { get; set; }
        public DateTime fecha_fin { get; set; }
    }
}