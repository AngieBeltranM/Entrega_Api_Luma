﻿using System;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Models
{
    [Table("Meta")]
    public class Meta
    {
        [Key]
        public int id_meta { get; set; }

        public int id_usuario { get; set; }
        public string nombre { get; set; } = string.Empty;
        public decimal monto_objetivo { get; set; }
        public decimal monto_actual { get; set; }
        public DateTime fecha_limite { get; set; }
        public string estado { get; set; } = string.Empty;
    }
}