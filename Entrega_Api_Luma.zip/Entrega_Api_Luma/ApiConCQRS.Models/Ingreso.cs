﻿using System;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Models
{
    [Table("Ingreso")]
    public class Ingreso
    {
        [Key]
        public int id_ingreso { get; set; }

        public int id_usuario { get; set; }
        public int id_categoria { get; set; }
        public decimal monto { get; set; }
        public DateTime fecha { get; set; }
        public string descripcion { get; set; } = string.Empty;
    }
}