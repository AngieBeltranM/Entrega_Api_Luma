﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface ICategoriaRepository
    {
        Task<int> CrearAsync(Categoria entidad);
        Task<bool> ActualizarAsync(Categoria entidad);
        Task<bool> EliminarAsync(int id_categoria);
    }
}
