﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Repository.Interfaces
{
    public interface IGastoRepository
    {
        Task<int> CrearAsync(Gasto entidad);
        Task<bool> ActualizarAsync(Gasto entidad);
        Task<bool> EliminarAsync(int id_gasto);
    }
}