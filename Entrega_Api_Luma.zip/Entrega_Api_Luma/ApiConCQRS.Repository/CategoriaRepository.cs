﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class CategoriaRepository : ICategoriaRepository
    {
        private readonly IDbConnection _connection;

        public CategoriaRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Categoria entidad)
        {
            const string sql = @"INSERT INTO Categoria (nombre, tipo)
                                  VALUES (@nombre, @tipo);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Categoria entidad)
        {
            const string sql = @"UPDATE Categoria
                                  SET nombre = @nombre, tipo = @tipo
                                  WHERE id_categoria = @id_categoria;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_categoria)
        {
            const string sql = "DELETE FROM Categoria WHERE id_categoria = @id_categoria;";
            var filas = await _connection.ExecuteAsync(sql, new { id_categoria });
            return filas > 0;
        }
    }
}
