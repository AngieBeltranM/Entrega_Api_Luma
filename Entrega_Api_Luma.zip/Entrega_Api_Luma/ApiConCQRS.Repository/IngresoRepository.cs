﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Repository.Interfaces;
using Dapper;

namespace ApiConCQRS.Repository
{
    public class IngresoRepository : IIngresoRepository
    {
        private readonly IDbConnection _connection;

        public IngresoRepository(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<int> CrearAsync(Ingreso entidad)
        {
            const string sql = @"INSERT INTO Ingreso (id_usuario, id_categoria, monto, fecha, descripcion)
                                  VALUES (@id_usuario, @id_categoria, @monto, @fecha, @descripcion);
                                  SELECT CAST(SCOPE_IDENTITY() AS int);";

            return await _connection.ExecuteScalarAsync<int>(sql, entidad);
        }

        public async Task<bool> ActualizarAsync(Ingreso entidad)
        {
            const string sql = @"UPDATE Ingreso
                                  SET id_usuario = @id_usuario, id_categoria = @id_categoria,
                                      monto = @monto, fecha = @fecha, descripcion = @descripcion
                                  WHERE id_ingreso = @id_ingreso;";

            var filas = await _connection.ExecuteAsync(sql, entidad);
            return filas > 0;
        }

        public async Task<bool> EliminarAsync(int id_ingreso)
        {
            const string sql = "DELETE FROM Ingreso WHERE id_ingreso = @id_ingreso;";
            var filas = await _connection.ExecuteAsync(sql, new { id_ingreso });
            return filas > 0;
        }
    }
}