﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class GastoQuery : IGastoQuery
    {
        private readonly IDbConnection _connection;

        public GastoQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Gasto?> ObtenerPorIdAsync(int id_gasto)
        {
            return await _connection.GetAsync<Gasto>(id_gasto);
        }

        public async Task<IEnumerable<Gasto>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Gasto>();
        }
    }
}