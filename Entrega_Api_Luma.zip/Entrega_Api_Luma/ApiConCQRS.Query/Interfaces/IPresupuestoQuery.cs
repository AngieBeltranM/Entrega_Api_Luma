﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface IPresupuestoQuery
    {
        Task<Presupuesto?> ObtenerPorIdAsync(int id_presupuesto);
        Task<IEnumerable<Presupuesto>> ObtenerTodosAsync();
    }
}