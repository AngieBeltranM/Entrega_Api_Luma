﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface ICategoriaQuery
    {
        Task<Categoria?> ObtenerPorIdAsync(int id_categoria);
        Task<IEnumerable<Categoria>> ObtenerTodosAsync();
    }
}