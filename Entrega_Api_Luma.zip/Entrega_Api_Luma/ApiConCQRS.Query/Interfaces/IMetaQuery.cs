﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface IMetaQuery
    {
        Task<Meta?> ObtenerPorIdAsync(int id_meta);
        Task<IEnumerable<Meta>> ObtenerTodosAsync();
    }
}
