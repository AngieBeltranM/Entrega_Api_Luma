﻿using ApiConCQRS.Models;

namespace ApiConCQRS.Query.Interfaces
{
    public interface IUsuarioQuery
    {
        Task<Usuario?> ObtenerPorIdAsync(int id_usuario);
        Task<IEnumerable<Usuario>> ObtenerTodosAsync();
    }
}