﻿using System.Data;
using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using Dapper.Contrib.Extensions;

namespace ApiConCQRS.Query
{
    public class IngresoQuery : IIngresoQuery
    {
        private readonly IDbConnection _connection;

        public IngresoQuery(IDbConnection connection)
        {
            _connection = connection;
        }

        public async Task<Ingreso?> ObtenerPorIdAsync(int id_ingreso)
        {
            return await _connection.GetAsync<Ingreso>(id_ingreso);
        }

        public async Task<IEnumerable<Ingreso>> ObtenerTodosAsync()
        {
            return await _connection.GetAllAsync<Ingreso>();
        }
    }
}