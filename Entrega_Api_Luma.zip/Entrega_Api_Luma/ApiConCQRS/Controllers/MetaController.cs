﻿using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ApiConCQRS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MetaController : ControllerBase
    {
        private readonly IMetaQuery _query;
        private readonly IMetaRepository _repository;

        public MetaController(IMetaQuery query, IMetaRepository repository)
        {
            _query = query;
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Meta>>> ObtenerTodos()
            => Ok(await _query.ObtenerTodosAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Meta>> ObtenerPorId(int id)
        {
            var resultado = await _query.ObtenerPorIdAsync(id);
            return resultado is null ? NotFound() : Ok(resultado);
        }

        [HttpPost]
        public async Task<ActionResult> Crear([FromBody] Meta entidad)
        {
            var id = await _repository.CrearAsync(entidad);
            return CreatedAtAction(nameof(ObtenerPorId), new { id }, entidad);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Actualizar(int id, [FromBody] Meta entidad)
        {
            entidad.id_meta = id;
            return await _repository.ActualizarAsync(entidad) ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Eliminar(int id)
            => await _repository.EliminarAsync(id) ? NoContent() : NotFound();
    }
}