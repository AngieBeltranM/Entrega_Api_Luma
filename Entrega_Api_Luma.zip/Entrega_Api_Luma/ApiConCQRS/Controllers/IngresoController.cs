﻿using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ApiConCQRS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IngresoController : ControllerBase
    {
        private readonly IIngresoQuery _query;
        private readonly IIngresoRepository _repository;

        public IngresoController(IIngresoQuery query, IIngresoRepository repository)
        {
            _query = query;
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Ingreso>>> ObtenerTodos()
            => Ok(await _query.ObtenerTodosAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Ingreso>> ObtenerPorId(int id)
        {
            var resultado = await _query.ObtenerPorIdAsync(id);
            return resultado is null ? NotFound() : Ok(resultado);
        }

        [HttpPost]
        public async Task<ActionResult> Crear([FromBody] Ingreso entidad)
        {
            var id = await _repository.CrearAsync(entidad);
            return CreatedAtAction(nameof(ObtenerPorId), new { id }, entidad);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Actualizar(int id, [FromBody] Ingreso entidad)
        {
            entidad.id_ingreso = id;
            return await _repository.ActualizarAsync(entidad) ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Eliminar(int id)
            => await _repository.EliminarAsync(id) ? NoContent() : NotFound();
    }
}