﻿using ApiConCQRS.Models;
using ApiConCQRS.Query.Interfaces;
using ApiConCQRS.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace ApiConCQRS.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriaController : ControllerBase
    {
        private readonly ICategoriaQuery _query;
        private readonly ICategoriaRepository _repository;

        public CategoriaController(ICategoriaQuery query, ICategoriaRepository repository)
        {
            _query = query;
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Categoria>>> ObtenerTodos()
            => Ok(await _query.ObtenerTodosAsync());

        [HttpGet("{id}")]
        public async Task<ActionResult<Categoria>> ObtenerPorId(int id)
        {
            var resultado = await _query.ObtenerPorIdAsync(id);
            return resultado is null ? NotFound() : Ok(resultado);
        }

        [HttpPost]
        public async Task<ActionResult> Crear([FromBody] Categoria entidad)
        {
            var id = await _repository.CrearAsync(entidad);
            return CreatedAtAction(nameof(ObtenerPorId), new { id }, entidad);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult> Actualizar(int id, [FromBody] Categoria entidad)
        {
            entidad.id_categoria = id;
            return await _repository.ActualizarAsync(entidad) ? NoContent() : NotFound();
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Eliminar(int id)
            => await _repository.EliminarAsync(id) ? NoContent() : NotFound();
    }
}
